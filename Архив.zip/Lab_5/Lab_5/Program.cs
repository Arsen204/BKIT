﻿using System;
using MyLib5;

namespace Lab_5
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine(MyLib5.Levenshtein.LevenshteinDistance("4примеrrр", "пирмер", damerau: false));
        }
    }
}
